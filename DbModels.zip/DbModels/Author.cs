﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BookApp.Models.DbModels
{
    public class Author
    {
        public int AuthorId { get;set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        // listy muszą zostać zainicjalizowane przed użyciem
        public List<Book> Books = new List<Book>();

        //konstruktor nieparametryczny
        public Author() { }  


        //konstruktor parametryczny
        public Author(int authorId, string name, string surname, List<Book> books)
        {
            AuthorId = authorId;
            Name = name;
            Surname = surname;
            Books = books;
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using BookApp.Models.DbModels;

namespace BookApp.Models
{


    // to plik  którym będziemy przechowywali wszystkie niezbędne informacje o bazie danych.

    public class DatabaseContext : DbContext
    {
        public DatabaseContext() : base("BookAppConnectionString") { }

        //dodaj trzy klasy DbSet: dla klas Book, Author, Library.
        public DbSet<Book> Books { get; set; }
        public DbSet<Author> Authors { get; set; }
        public DbSet<Library> Libraries { get; set; }



    }
}